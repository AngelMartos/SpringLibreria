package com.example.proyectofinal.Clases;

import java.util.List;

public class ReservasResponse {
    private List<Reserva> reservas;

    public List<Reserva> getReservas() {
        return reservas;
    }

    public void setReservas(List<Reserva> reservas) {
        this.reservas = reservas;
    }
}